<?php
/**
 * Created by PhpStorm.
 * User: 琛
 * Date: 2019/5/8
 * Time: 11:31
 */
include_once './inc/config.inc.php';
include_once './inc/mysql.inc.php';
include_once './inc/tool.inc.php';
require "./inc/upload_file.php";

$link=connect();
if(isset($_POST['submit'])){
    if(isset($_COOKIE['sfk']['name'])){
        $teacher = $_COOKIE['sfk']['name'];
    }
    $km = $_POST['km'];
    $name = $_POST['name'];
    $neirong = $_POST['neirong'];
    $time = date('Y-m-d h:i:s', time());
    $dizhi = $newName.".".$arr['extension'];
    $query="insert into newwork(km,name,teacher,time,dizhi,neirong,kmnum) values('{$km}','{$name}','{$teacher}','{$time}','{$dizhi}','{$neirong}','{$kmnum}')";
    $result = execute($link,$query);
    if($result){
        skip('fawork.php', 'ok', '发布成功！');

    }else{
        skip('fawork.php', 'error', '发布失败！');

    }
}

?>
<!DOCTYPE html >
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>新建作业</title>
    <link rel="icon" href="images/1.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Audiowide" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Montserrat+Alternates" rel="stylesheet">

</head>
<body>
<div class="wrap ">
    <div class="section sTop">
        <div class="top-container">
            <div class="container">
                <div class="newwork" style="color: #fff;">
                    <div class="container">
                        <div class="row clearfix">
                            <div class="col-md-2 column">
                            </div>
                            <div class="col-md-8 column">
                                <ol class="breadcrumb">
                                    <li><a href="teacher.php">首页</a></li>
                                    <li><a href="newwork.php">发布作业</a></li>
                                    <li class="active">新建作业</li>
                                </ol>
                                <form  action="fawork.php" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">科目代号：</label><input type="text" name="kmnum" class="form-control" id="exampleInputEmail1" />
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">科目名称：</label><input type="text" name="km" class="form-control" id="exampleInputEmail1" />
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">标题：</label><input type="text" name="name" class="form-control" id="exampleInputPassword1" />
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">内容：</label><input type="text" name="neirong" class="form-control" id="exampleInputPassword1" />
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputFile">上传的课件</label><input type="file" name="myfile" id="exampleInputFile" />
                                    </div>
                                      <input type="submit" class="btn btn-default" name="submit" value="确认发布">
                                  </form>
                            </div>
                            <div class="col-md-2 column">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script>

</script>

