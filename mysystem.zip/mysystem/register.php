<?php
require './inc/config.inc.php';
require './inc/mysql.inc.php';
require './inc/tool.inc.php';

if(isset($_POST['sub'])){
    $link=connect();
    require './inc/check_register.inc.php';
    if($_POST['tt']==0){
        $query="insert into student(name,password,number) values('{$_POST['name']}',md5('{$_POST['password']}'),'{$_POST['number']}')";
        execute($link,$query);
        if(mysqli_affected_rows($link)==1){
            setcookie('sfk[name]',$_POST['name']);
            setcookie('sfk[password]',md5($_POST['password']));

            skip('student.php','ok','注册成功！');
        }else{
            skip('index.php','eror','注册失败,请重试！');
        }

    }else{
        $query="insert into teacher(name,password,number) values('{$_POST['name']}',md5('{$_POST['password']}'),'{$_POST['number']}')";
        execute($link,$query);
        if(mysqli_affected_rows($link)==1){
            setcookie('sfk[name]',$_POST['name']);
            setcookie('sfk[password]',md5($_POST['password']));

            skip('teacher.php','ok','注册成功！');
        }else{
            skip('index.php','eror','注册失败,请重试！');
        }
    }

}
?>