<?php 
if(empty($_POST['name'])){
	skip('index.html', 'error', '用户名不得为空！');
}
if(mb_strlen($_POST['name'])>12){
	skip('index.html', 'error', '用户名长度不要超过12个字符！');
}
if(empty($_POST['password'])){
	skip('index.html', 'error', '密码不得为空！');
}
if(strtolower($_POST['code'])!=strtolower($_SESSION['vcode'])){
	skip('index.html', 'error','验证码输入错误！');
}

?>