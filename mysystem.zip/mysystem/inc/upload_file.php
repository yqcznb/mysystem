<?php

header('Content-type:text/html;charset = utf-8');

if(isset($_POST['submit'])) {


    if (is_uploaded_file($_FILES['myfile']['tmp_name'])) {
        $arr = pathinfo($_FILES['myfile']['name']);
        $newName = date('YmdGis') . rand(1000, 9999);
        if (move_uploaded_file($_FILES['myfile']['tmp_name'], "tckj/".$newName.".".$arr['extension'])) {
            echo '<script>alert("恭喜你上传成功")</script>';
              } else {
            echo '<script>alert("恭喜你上传失败")</script>';
        }
    } else {
        exit('可能会有攻击');
    }
}




?>