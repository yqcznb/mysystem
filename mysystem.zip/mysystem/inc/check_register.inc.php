<?php 
if(empty($_POST['name'])){
	   $nameErr = "用户名不得为空！";
    skip('index.html', 'error', '这个用户名已经被别人注册了！');
} else {
    $name =$_POST["name"];
    if (!preg_match("/^[\x7f-\xff]+$/",$name)) {
        skip('index.html', 'error', '请输入真实姓名');
    }
}
if(mb_strlen($_POST['password'])<6){
    skip('index.html', 'error', '密码不得少于6位！');
}else{
    $password =$_POST['password'];
    if (!preg_match("/^[a-zA-Z][A-Za-z0-9]{6,20}$/",$password)) {
        skip('index.html', 'error', '密码以字母开头，只能包含数字和下划线');
    }
}
if($_POST['password']!=$_POST['password2']){
    skip('index.html', 'error', '两次密码输入不一致！');
}
if(strtolower($_POST['vcode'])!=strtolower($_SESSION['vcode'])){
    skip('index.html', 'error', '验证码输入错误！');
}
$_POST=escape($link,$_POST);
if($_POST['tt']==0){
    $query="select * from student where name='{$_POST['name']}'";
}else{
    $query="select * from teacher where name='{$_POST['name']}'";
}
$result=execute($link, $query);
if(mysqli_num_rows($result)){
	skip('index.html', 'error', '这个用户名已经被别人注册了！');
}
?>