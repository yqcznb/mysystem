<?php
include_once 'config.inc.php';
include_once 'mysql.inc.php';
include_once 'tool.inc.php';
$link=connect();
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = mysqli_query($link, "SELECT * FROM newwork WHERE id=$id");
    $sql_arr = mysqli_fetch_assoc($sql);
    $teacher = $sql_arr['teacher'];

    $kmnum= $sql_arr['kmnum'];
    mysqli_free_result($sql);
    $sqll = execute($link, "SELECT * FROM teacher WHERE name='" . $teacher . "'");
    $sqll_arr = mysqli_fetch_assoc($sqll);
    $number= $sqll_arr['number'];
    $dir="../xszy/" . $kmnum . "/" . $number."/";

}
	$filename = "../xszy/" . $kmnum . "/" . $number."/"."homework.zip";
	zip($dir,$filename);
	function zip($dir_path,$zipName){
	    $relationArr = [$dir_path=>[
	        'originName'=>$dir_path,
	        'is_dir' => true,
	        'children'=>[]
	    ]];
	    modifiyFileName($dir_path,$relationArr[$dir_path]['children']);
	    $zip = new ZipArchive();
	    $zip->open($zipName,ZipArchive::CREATE);
	    zipDir(array_keys($relationArr)[0],'',$zip,array_values($relationArr)[0]['children']);
	    $zip->close();
	    restoreFileName(array_keys($relationArr)[0],array_values($relationArr)[0]['children']);
	}

	function zipDir($real_path,$zip_path,&$zip,$relationArr){
	    $sub_zip_path = empty($zip_path)?'':$zip_path.'\\';
	    if (is_dir($real_path)){
	        foreach($relationArr as $k=>$v){
	            if($v['is_dir']){  //是文件夹
	                $zip->addEmptyDir($sub_zip_path.$v['originName']);
	                zipDir($real_path.'\\'.$k,$sub_zip_path.$v['originName'],$zip,$v['children']);
	            }else{ //不是文件夹
	                $zip->addFile($real_path.'\\'.$k,$sub_zip_path.$k);
	                $zip->deleteName($sub_zip_path.$v['originName']);
	                $zip->renameName($sub_zip_path.$k,$sub_zip_path.$v['originName']);
	            }
	        }
	    }
	}
	function modifiyFileName($path,&$relationArr){
	    if(!is_dir($path) || !is_array($relationArr)){
	        return false;
	    }
	    if($dh = opendir($path)){
	        $count = 0;
	        while (($file = readdir($dh)) !== false){
	            if(in_array($file,['.','..',null])) continue; //无效文件，重来
	            if(is_dir($path.'\\'.$file)){
	                $newName = md5(rand(0,99999).rand(0,99999).rand(0,99999).microtime().'dir'.$count);
	                $relationArr[$newName] = [
	                    'originName' => iconv('GBK','UTF-8',$file),
	                    'is_dir' => true,
	                    'children' => []
	                ];
	                @rename($path.'\\'.$file, $path.'\\'.$newName);
	                modifiyFileName($path.'\\'.$newName,$relationArr[$newName]['children']);
	                $count++;
	            }
	            else{
	                $extension = strchr($file,'.');
	                $newName = md5(rand(0,99999).rand(0,99999).rand(0,99999).microtime().'file'.$count);
	                $relationArr[$newName.$extension] = [
	                    'originName' => iconv('GBK','UTF-8',$file),
	                    'is_dir' => false,
	                    'children' => []
	                ];
	                @rename($path.'\\'.$file, $path.'\\'.$newName.$extension);
	                $count++;
	            }
	        }
	    }
	}
	function restoreFileName($path,$relationArr){
	    foreach($relationArr as $k=>$v){
	        if(!empty($v['children'])){
	            restoreFileName($path.'\\'.$k,$v['children']);
	            @rename($path.'\\'.$k,iconv('UTF-8','GBK',$path.'\\'.$v['originName']));
	        }else{
	            @rename($path.'\\'.$k,iconv('UTF-8','GBK',$path.'\\'.$v['originName']));
	        }
	    }
	}
	
?>
<!DOCTYPE html >
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>新建作业</title>
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Audiowide" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Montserrat+Alternates" rel="stylesheet">

</head>
<body>
<div class="wrap ">
    <div class="section sTop">
        <div class="top-container">
            <div class="container">
                <div class="newwork" style="color: #fff;">
                    <div class="container">
                        <div class="row clearfix">
                            <div class="col-md-2 column">
                            </div>
                            <div class="col-md-8 column">
                                <ol class="breadcrumb">
                                    <li><a href="../teacher.php">首页</a></li>
                                    <li><a href="../newwork.php">发布作业</a></li>
                                    <li class="active">下载</li>
                                </ol>
                                <a href=<?php echo $filename;?>>下载</a>
                                <a href="../lookhomework.php">返回</a>
                            </div>
                            <div class="col-md-2 column">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script>

</script>

