<?php
include_once 'config.inc.php';
include_once 'mysql.inc.php';
$link=connect();
if(isset($_POST['km'])){
    $km = $_POST['km'];
}else{
    $km = " ";
}if(isset($_POST['name'])){
    $name = $_POST['name'];
}else{
    $name = " ";
}if(isset($_POST['teacher'])){
    $teacher = $_POST['teacher'];
}else{
    $teacher = " ";
}if(isset($_POST['neirong'])){
    $neirong = $_POST['neirong'];
}else{
    $neirong = " ";
}
$id =$_POST['id'];
$time = date('Y-m-d h:i:s', time());
mysqli_query($link,"UPDATE newwork SET km='$km',name='$name',neirong='$neirong',teacher='$teachar',time='$time' WHERE id=$id") or die('修改数据出错：'.mysqli_error());
header("Location:../mywork.php");