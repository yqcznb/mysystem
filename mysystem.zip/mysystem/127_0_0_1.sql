-- phpMyAdmin SQL Dump
-- version 4.0.10.11
-- http://www.phpmyadmin.net
--
-- 主机: 127.0.0.1
-- 生成日期: 2019-06-12 10:47:21
-- 服务器版本: 5.5.54-log
-- PHP 版本: 7.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `home`
--

-- --------------------------------------------------------

--
-- 表的结构 `newwork`
--

CREATE TABLE IF NOT EXISTS `newwork` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `km` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `teacher` varchar(32) NOT NULL,
  `time` datetime NOT NULL,
  `dizhi` varchar(32) NOT NULL,
  `neirong` varchar(255) NOT NULL,
  `kmnum` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `newwork`
--

INSERT INTO `newwork` (`id`, `km`, `name`, `teacher`, `time`, `dizhi`, `neirong`, `kmnum`) VALUES
(2, 'php', '尹琦琛', '尹琦琛', '2019-06-11 07:47:42', '201906092155176842.png', '111', 3),
(3, 'php', '777', '尹琦琛', '2019-06-10 11:49:09', '201906092230412337.png', '111', 3),
(4, 'php', '尹琦琛', '尹琦琛', '2019-06-09 07:27:42', '201906112007237091.css', '111', 3),
(5, 'php', '尹琦琛', '尹琦琛', '2019-06-09 07:29:28', '', '111', 3),
(9, 'js', '11', '尹琦琛', '2019-06-09 07:43:01', '', '', 1),
(8, 'js', '11', '尹琦琛', '2019-06-09 07:39:39', '', '', 1),
(10, 'vue', '22', '尹琦琛', '2019-06-09 07:43:44', '', '', 0),
(11, 'vue', '22', '尹琦琛', '2019-06-10 08:48:00', '', '', 0),
(12, 'vue', '22', '尹琦琛', '2019-06-09 07:47:36', '', '', 0),
(13, 'html', '33', '尹琦琛', '2019-06-09 07:48:42', '', '', 2),
(14, 'html', '33', '尹琦琛', '2019-06-09 07:51:11', '', '', 2),
(15, 'html', '33', '尹琦琛', '2019-06-09 09:54:25', '', '', 2),
(16, 'html', '33', '尹琦琛', '2019-06-09 09:55:18', '', '', 2);

-- --------------------------------------------------------

--
-- 表的结构 `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `number` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `student`
--

INSERT INTO `student` (`id`, `name`, `password`, `number`) VALUES
(8, '尹琦琛', 'db99afa504a4d3ebc1fced335077c660', '201702505247');

-- --------------------------------------------------------

--
-- 表的结构 `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `number` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `teacher`
--

INSERT INTO `teacher` (`id`, `name`, `password`, `number`) VALUES
(8, '尹琦琛', 'db99afa504a4d3ebc1fced335077c660', '201702505247');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
