<?php
/**
 * Created by PhpStorm.
 * User: 琛
 * Date: 2019/5/8
 * Time: 11:31
 */


?>
<!DOCTYPE html >
<html>
<head>
    <link rel="icon" href="images/1.ico" type="image/x-icon"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>学生界面</title>
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
</head>
<body>
<div class="wrap ">
    <div class="section sTop">
        <div class="top-container">

            <div class="container">

                <div class="large-logo">
                    <a href="#"><img src="images/1.png" alt="logo" /></a>
                </div>

                <div class="vticker">
                    <ul>
                        <li>胸怀天下</li>
                        <li>造福人类</li>
                        <li>您好！<?php
                            if(isset($_COOKIE['sfk']['name'])){
                                echo "{$_COOKIE['sfk']['name']}同学";
                            }?></li>
                    </ul>
                </div>
                <div class="" >
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="snewpassword.php"><i class="fa fa-cog"></i>设置</a></li>
                        <li><a href="supwork.php"><i class="fa fa-cloud-upload"></i>上传作业</a></li>
                        <li><a href="sxiazai.php"><i class="fa fa-cloud-download"></i>下载课件</a></li>
                        <li><a href="#"><i class="fa fa-picture-o"></i>我的上传</a></li>
                        <li><a href="#"><i class="fa fa-pencil-square-o"></i>Blog</a></li>
                        <li><a href="#" onclick="tuichu()"><i class="fa fa-paper-plane"></i>退出</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<script>
    function tuichu() {
        if(confirm("确认退出？")) {
            window.location.href="index.html"
        }
    }
</script>

