<?php
/**
 * Created by PhpStorm.
 * User: 琛
 * Date: 2019/5/8
 * Time: 11:31
 */
include_once './inc/config.inc.php';
include_once './inc/mysql.inc.php';
include_once './inc/tool.inc.php';
require "./inc/page.inc.php";

$link=connect();
$cc = $_COOKIE['sfk']['name'];
$aa = "select count(*) from newwork WHERE teacher='{$cc}' ";
$count_all = mysqli_query($link,$aa);
$bb = mysqli_fetch_row($count_all)[0];
$page=page($bb,5,5);
$sql = "select * from newwork WHERE teacher='{$cc}'  order by id   {$page['limit']}";
$result = mysqli_query($link,$sql);
$num=mysqli_num_rows($result);



?>
<!DOCTYPE html >
<html>
<head>
    <link rel="icon" href="images/1.ico" type="image/x-icon"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>我的发布</title>
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="style/public.css">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Audiowide" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Montserrat+Alternates" rel="stylesheet">

</head>
<body>
<div class="wrap ">
    <div class="section sTop">
        <div class="top-container">

            <div class="container">
                <div class="newwork">
                    <div class="container">
                        <div class="row clearfix">
                            <div class="col-md-2 column">
                                <div class="btn-group btn-group-vertical btn-group-lg">
                                    <button class="btn btn-default" type="button"><a href="fawork.php">新建作业</a></button>
                                    <button class="btn btn-default" type="button">科目</button>
                                    <button class="btn btn-default" type="button"> 教师</button>
                                    <button class="btn btn-default" type="button"><a href="teacher.php">返回</a></button>
                                </div>
                            </div>
                            <div class="col-md-10 column">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span  id='aa' class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                     </span>
                                </div>
                                <br><br>
                                <div class="jumbotron">
                                    <?php
                                    for ($i = 0;$i < $num;$i++){
                                        $row = mysqli_fetch_assoc($result);
                                        if(isset($row['km'])){
                                            $km = $row['km'];
                                        }else{
                                            $km = " ";
                                        }if(isset($row['name'])){
                                            $name = $row['name'];
                                        }else{
                                            $name = " ";
                                        }if(isset($row['teacher'])){
                                            $teacher = $row['teacher'];
                                        }else{
                                            $teacher = " ";
                                        }if(isset($row['neirong'])){
                                            $neirong = $row['neirong'];
                                        }else{
                                            $neirong = " ";
                                        }

                                         $time = $row['time'];
                                         echo "<ul class=\"list-group\">
                                                  <li class=\"list-group-item list-group-item-success\">$km--$name--$teacher--$time--$neirong <a href='xiangqing.php?id={$row['id']}'>查看详情</a></li>
                                                </ul>";
                                    }
                                    ?>
                                </div>
                                <ul class="pagination">
                                    <?php
                                    echo $page['html'];
                                    ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>
</body>
</html>
<script>

</script>

