<?php
/**
 * Created by PhpStorm.
 * User: 琛
 * Date: 2019/5/8
 * Time: 11:31
 */
include_once './inc/config.inc.php';
include_once './inc/mysql.inc.php';
include_once './inc/tool.inc.php';

$link=connect();
$id = $_GET['id'];
$sql = mysqli_query($link,"SELECT * FROM newwork WHERE id=$id");
$sql_arr = mysqli_fetch_assoc($sql);

?>
<!DOCTYPE html >
<html>
<head>
    <link rel="icon" href="images/1.ico" type="image/x-icon"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>查看详情</title>
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Audiowide" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Montserrat+Alternates" rel="stylesheet">

</head>
<body>
<div class="wrap ">
    <div class="section sTop">
        <div class="top-container">
            <div class="container">
                <div class="newwork" style="color: #fff;">
                    <div class="container">
                        <div class="row clearfix">
                            <div class="col-md-2 column">
                            </div>
                            <div class="col-md-8 column">
                                <ol class="breadcrumb">
                                    <li><a href="teacher.php">首页</a></li>
                                    <li><a href="newwork.php">发布作业</a></li>
                                    <li class="active">查看详情</li>
                                </ol>
                                <form action="./inc/new.php" method="post" enctype="multipart/form-data">
                                    <ul class="list-group">
                                        <li class="list-group-item list-group-item-success">ID：<input name="id" value="<?php echo $id?>"></li>
                                        <li class="list-group-item list-group-item-success">科目名称：<input name="km" value="<?php echo $sql_arr['km']?>"></li>
                                        <li class="list-group-item list-group-item-info">标题：<input name="name" value="<?php echo $sql_arr['name']?>"></li>
                                        <li class="list-group-item list-group-item-warning">教师:<input value="<?php echo $sql_arr['teacher']?>" name="teacher"></li>
                                        <li class="list-group-item list-group-item-danger">时间:<?php echo $sql_arr['time']?></li>
                                        <li class="list-group-item list-group-item-success">内容：<input name="neirong" value="<?php echo $sql_arr['neirong']?>"></li>
                                        <li class="list-group-item list-group-item-info">课件：<a href="./inc/up.php?ff="> 下载</a></li>
                                    </ul>
                                    <input name="submit" value="确认修改" type="submit" style="color: #0b0b0b">
                                </form>
                            </div>
                            <div class="col-md-2 column">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script>

</script>

