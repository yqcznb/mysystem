<?php
/**
 * Created by PhpStorm.
 * User: 琛
 * Date: 2019/5/8
 * Time: 11:31
 */
include_once './inc/config.inc.php';
include_once './inc/mysql.inc.php';
include_once './inc/tool.inc.php';

$link=connect();
if(isset($_POST['submit'])){
    if(isset($_COOKIE['sfk']['password'])){
        $password = $_COOKIE['sfk']['password'];
        if($password!=md5($_POST['password'])){
            echo "<script>alert('原密码不对')</script>";
        }
        if($_POST['password1']!=$_POST['password2']){
            echo "<script>alert('两次密码输入不一致')</script>";
        }
    }
    $ps = md5($_POST['password1']);
    $query="UPDATE student SET password='$ps' WHERE password='$password'";
    $result = execute($link,$query);
    if($result){
        skip('index.html', 'ok', '密码修改成功，请重新登录！');

    }else{
        skip('student.php', 'error', '密码修改失败！');

    }
}

?>
<!DOCTYPE html >
<html>
<head>
    <link rel="icon" href="images/1.ico" type="image/x-icon"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>修改密码</title>
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Audiowide" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/css?family=Montserrat+Alternates" rel="stylesheet">

</head>
<body>
<div class="wrap ">
    <div class="section sTop">
        <div class="top-container">
            <div class="container">
                <div class="newwork" style="color: #fff;">
                    <div class="container">
                        <div class="row clearfix">
                            <div class="col-md-2 column">
                            </div>
                            <div class="col-md-8 column">
                                <ol class="breadcrumb">
                                    <li><a href="student.php">首页</a></li>
                                    </ol>
                                <form  action="snewpassword.php" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">旧密码：</label><input type="text" name="password" class="form-control" id="exampleInputEmail1" />
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">新密码：</label><input type="text" name="password1" class="form-control" id="exampleInputEmail1" />
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">确认密码：</label><input type="text" name="password2" class="form-control" id="exampleInputPassword1" />
                                    </div>
                                   <input type="submit" class="btn btn-default" name="submit" value="确认修改">
                                </form>
                            </div>
                            <div class="col-md-2 column">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script>

</script>

