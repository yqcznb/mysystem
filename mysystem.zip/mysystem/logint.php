<?php
include_once './inc/config.inc.php';
include_once './inc/mysql.inc.php';
include_once './inc/tool.inc.php';
$link=connect();
if(isset($_POST['submit'])) {
    include './inc/check_logint.inc.php';
    escape($link, $_POST);
    if ($_POST['tt'] == 0) {
        $query = "select * from student where name='{$_POST['name']}' and password=md5('{$_POST['password']}')";
        $result = execute($link, $query);
        if (mysqli_num_rows($result) == 1) {
            setcookie('sfk[name]', $_POST['name'], time() + 3600);
            setcookie('sfk[password]', md5($_POST['password']), time() + 3600);
            skip('student.php', 'ok', '登录成功！');
        } else {
            skip('index.html', 'error', '用户名或密码填写错误！');
        }

    } else {
        $query = "select * from teacher where name='{$_POST['name']}' and password=md5('{$_POST['password']}')";
        $result = execute($link, $query);
        if (mysqli_num_rows($result) == 1) {
            setcookie('sfk[name]', $_POST['name'], time() + 3600);
            setcookie('sfk[password]', md5($_POST['password']), time() + 3600);
            skip('teacher.php', 'ok', '登录成功！');
        } else {
            skip('index.html', 'error', '用户名或密码填写错误！');
        }
    }
}
?>
